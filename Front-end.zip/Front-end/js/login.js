document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const statusDiv = document.getElementById('login-status');

    // Simulated user database
    const users = {
        'doctor@example.com': { password: 'pass', role: 'doctor' },
        'patient@example.com': { password: 'pass', role: 'patient' },
        'admin@example.com': { password: 'pass', role: 'admin' },
    };

    const redirectUrls = {
        'doctor': 'doctor-dashboard.html', 
        'patient': 'patient-dashboard.html', 
        'admin': 'admin-dashboard.html', 
    };

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = emailInput.value.trim().toLowerCase();
        const password = passwordInput.value;
        
        statusDiv.classList.add('hidden');

        // Simple input validation
        if (!email || !password) {
            statusDiv.textContent = 'Please enter both email and password.';
            statusDiv.classList.remove('hidden');
            return;
        }

        const user = users[email];

        if (user && user.password === password) {
            // Success: Perform redirection
            statusDiv.textContent = `Log In successful! Redirecting to ${user.role} dashboard...`;
            statusDiv.classList.remove('text-danger');
            statusDiv.classList.add('text-primary');
            statusDiv.classList.remove('hidden');

            setTimeout(() => {
                // Redirect user based on their role
                window.location.href = redirectUrls[user.role];
            }, 1000);

        } else {
            // Failure: Show error message
            statusDiv.textContent = 'Invalid email or password. Please try again.';
            statusDiv.classList.add('text-danger');
            statusDiv.classList.remove('hidden');
        }
    });

    // --- REMOVED AUTOFILLED CREDENTIALS ---
});