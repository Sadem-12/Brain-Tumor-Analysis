// --- DATA SIMULATION (In a real app, this would be fetched from Firestore) ---
let patientData = {
    name: "Mohammad Naif",
    id: "P-4438123",
    email: "m.naif@example.com", // <-- NEW FIELD
    age: 51,
    gender: "Male",
    height: "181 cm",
    weight: "79 kg",
    doctor: "Dr. Kiran Patel",
    // MODIFIED: Initial phone number set to 10 digits starting with 05
    phone: "0544381230" 
    // Note: Password itself is not stored here in plain text.
};

const reportHistory = [
    { id: 'scn-005', date: 'Apr 10, 2025', finding: 'Glioma Tumor', probability: '91%', doctor: 'Dr. Patel' },
    { id: 'scn-004', date: 'Oct 15, 2024', finding: 'No Tumor Detected', probability: '99%', doctor: 'Dr. Patel' },
    { id: 'scn-003', date: 'Feb 02, 2024', finding: 'Pituitary Microadenoma', probability: '65%', doctor: 'Dr. Omar' },
    { id: 'scn-002', date: 'May 01, 2023', finding: 'No Tumor Detected', probability: '98%', doctor: 'Dr. Omar' },
    { id: 'scn-001', date: 'Jan 15, 2023', finding: 'No Tumor Detected', probability: '99%', doctor: 'Dr. Omar' },
];

const messageInbox = [
    {
        id: 101,
        sender: 'Dr. Kiran Patel',
        subject: 'Follow-up Required for Scan SCN-005',
        body: "Mr. Naif, I have reviewed the SCN-005 report. The high probability necessitates an immediate consultation. Please call my office this week to schedule a time to discuss the biopsy.",
        date: 'Apr 11, 2025',
        read: false,
    },
    {
        id: 102,
        sender: 'System Alert',
        subject: 'New Report Available: SCN-005',
        body: "Your new MRI analysis report (SCN-005) is now available in the 'My Reports' section.",
        date: 'Apr 10, 2025',
        read: false,
    },
    {
        id: 103,
        sender: 'Dr. Kiran Patel',
        subject: 'Re: Question about SCN-004',
        body: "Yes, I confirm the SCN-004 scan showed no anomalies. We can proceed with the standard 6-month follow-up schedule.",
        date: 'Oct 16, 2024',
        read: true,
    }
];

// --- DOM ELEMENTS AND CONSTANTS ---
const sidebar = document.getElementById('sidebar');
const menuBtn = document.getElementById('menu-btn');
const pageTitle = document.getElementById('page-title');
const reportsListBody = document.getElementById('reports-list');
// Changed to target the <tbody> element
const messageInboxBody = document.getElementById('message-inbox-body');
const unreadCountSpan = document.getElementById('unread-count');

const reportModal = document.getElementById('reportModal');
// NEW: Reference to the new message modal
const messageModal = document.getElementById('messageModal'); 

// Use the ID of the form inside the new combined section
const contactForm = document.getElementById('contact-form');
const profileUpdateForm = document.getElementById('profile-update-form');

// ⭐ NEW HELPER FUNCTION FOR EMAIL VALIDATION
function validateEmail(email) {
    // Basic regex pattern for email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
// ⭐ END NEW HELPER FUNCTION


// --- RENDERING FUNCTIONS ---

function formatPhoneNumberDisplay(number) {
    // Formats the 10-digit 05XXXXXXXX number for display
    if (number && number.length === 10 && number.startsWith('05')) {
        return `+966 ${number.substring(0, 4)}xxxxxxx`;
    }
    return number; 
}

function populatePatientInfo() {
    // Dashboard Summary Info
    document.getElementById('patient-name').textContent = patientData.name;
    document.getElementById('patient-id').textContent = `ID: ${patientData.id}`;
    document.getElementById('info-age').textContent = patientData.age;
    document.getElementById('info-gender').textContent = patientData.gender;
    document.getElementById('info-height').textContent = patientData.height;
    document.getElementById('info-weight').textContent = patientData.weight;
    document.getElementById('info-doctor').textContent = patientData.doctor;
    document.getElementById('info-phone').textContent = formatPhoneNumberDisplay(patientData.phone);

    // Profile Form Defaults
    document.getElementById('profile-name').value = patientData.name;
    document.getElementById('profile-id-display').value = patientData.id; // <-- New Readonly ID field
    document.getElementById('profile-email').value = patientData.email; // <-- New Email field
    document.getElementById('profile-phone').value = patientData.phone;
    document.getElementById('profile-age').value = patientData.age;
    document.getElementById('profile-gender').value = patientData.gender;
    document.getElementById('profile-height').value = parseInt(patientData.height);
    document.getElementById('profile-weight').value = parseInt(patientData.weight);

    // Update latest report summary on dashboard
    const latestReport = reportHistory[0];
    document.getElementById('summary-probability').textContent = `${latestReport.probability} Probability`;
    document.getElementById('summary-date').textContent = `Scanned on: ${latestReport.date}`;

    const findingText = latestReport.finding === 'No Tumor Detected' ? 'No tumor detected. Follow-up advised.' : latestReport.finding;
    document.getElementById('summary-diagnosis').textContent = findingText;
    
    const imageText = latestReport.finding.includes('Tumor') ? 'Tumor' : 'Clear';
    document.getElementById('latest-scan-image').src = `https://placehold.co/300x300/00bcd4/0f2027?text=${imageText}`;

    // Update Unread Message Count
    const unreadCount = messageInbox.filter(msg => !msg.read).length;
    unreadCountSpan.textContent = unreadCount;
    unreadCountSpan.classList.toggle('hidden', unreadCount === 0);
}

function renderReportHistory() {
    reportsListBody.innerHTML = reportHistory.map(report => {
        const isWarning = report.finding.includes('Tumor') || report.finding.includes('Microadenoma');
        
        return `
            <tr class="${isWarning ? 'bg-red-900/10 hover:bg-red-900/20' : 'hover:bg-primary/20'} cursor-pointer">
                <td class="px-4 py-3 font-medium text-white">${report.id}</td>
                <td class="px-4 py-3 text-gray-200">${report.date}</td>
                <td class="px-4 py-3 text-sm font-medium ${isWarning ? 'text-danger' : 'text-primary'}">${report.finding}</td>
                <td class="px-4 py-3 font-semibold text-gray-200">${report.probability}</td>
                <td class="px-4 py-3 text-gray-300">${report.doctor}</td>
                <td class="px-4 py-3 whitespace-nowrap text-sm font-medium space-x-2">
                    <button onclick="viewFullReport('${report.id}')" class="text-primary hover:text-secondary transition">
                        View
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// RENDER MESSAGE INBOX AS A TABLE (similar to reports)
function renderMessageInbox() {
    messageInboxBody.innerHTML = messageInbox.map(msg => {
        const isUnread = !msg.read;
        const isAlert = msg.sender.includes('System Alert');
        
        const rowBg = isUnread ? 'bg-primary/10 hover:bg-primary/20' : 'hover:bg-card-bg/50';
        const senderColor = isAlert ? 'text-yellow-400 font-bold' : isUnread ? 'text-white font-bold' : 'text-gray-200';
        const subjectColor = isUnread ? 'text-white' : 'text-gray-300';

        return `
            <tr onclick="showMessageBody(${msg.id})" class="${rowBg} cursor-pointer transition">
                <td class="px-4 py-3 text-sm whitespace-nowrap">
                    <span class="inline-block w-2 h-2 rounded-full mr-2 ${isUnread ? 'bg-danger' : 'bg-transparent'}"></span>
                    <span class="${senderColor}">${msg.sender}</span>
                </td>
                <td class="px-4 py-3 text-sm truncate ${subjectColor}">
                    ${msg.subject}
                </td>
                <td class="px-4 py-3 text-sm whitespace-nowrap text-gray-400">${msg.date}</td>
                <td class="px-4 py-3 text-sm whitespace-nowrap">
                    <button onclick="showMessageBody(${msg.id})" class="text-primary hover:text-secondary transition">
                        View
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Global function to show the message content in a modal
window.showMessageBody = function(msgId) {
    const msg = messageInbox.find(m => m.id === msgId);
    if (!msg) return;

    // Simulate marking as read
    if (!msg.read) {
        msg.read = true;
        populatePatientInfo(); // Update unread count in sidebar
        renderMessageInbox(); // Re-render the list to remove bold/highlight
    }

    // Populate the modal content
    document.getElementById('msg-sender').textContent = msg.sender;
    document.getElementById('msg-date').textContent = msg.date;
    document.getElementById('msg-subject').textContent = msg.subject;
    document.getElementById('msg-body').textContent = msg.body;

    // Show the modal
    messageModal.showModal();
}

window.viewFullReport = function(scanId) {
    const report = reportHistory.find(r => r.id === scanId);
    if (!report) return;

    document.getElementById('report-modal-title').textContent = `Diagnostic Report (ID: RPT-${scanId.split('-')[1]})`;
    
    reportModal.showModal();
}

// --- INTERACTION LOGIC ---

// Mobile Menu Toggle
menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('-translate-x-full');
});

// Navigation Handler
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();

        const targetSectionId = this.getAttribute('data-section');
        const targetSection = document.getElementById(targetSectionId);

        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.add('hidden');
        });

        // Show target section
        if (targetSection) {
            targetSection.classList.remove('hidden');
            pageTitle.textContent = this.textContent;
            
            // Special function call for rendering inbox when navigating there
            if (targetSectionId === 'messages') {
                renderMessageInbox();
            }
        }

        // Update active link styling
        document.querySelectorAll('nav a').forEach(nav => nav.classList.remove('bg-primary/30', 'active-link'));
        this.classList.add('bg-primary/30', 'active-link');

        // Hide mobile menu after selection
        if (window.innerWidth < 768) {
            sidebar.classList.add('-translate-x-full');
        }
    });
});

// Contact Form Simulation
contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const contactStatus = document.getElementById('contact-status');
    contactStatus.classList.remove('hidden');
    contactStatus.classList.add('text-primary');
    contactStatus.textContent = 'Sending message...';

    setTimeout(() => {
        // Simulate a new message being sent to the doctor
        messageInbox.unshift({
            id: Date.now(),
            sender: 'You',
            subject: document.getElementById('subject').value,
            body: document.getElementById('message-body').value,
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            read: true, // Sender has read it
        });

        contactStatus.textContent = 'Message sent successfully! Check your Messages inbox for a reply.';
        contactStatus.classList.remove('text-primary');
        contactStatus.classList.add('text-primary');
        contactForm.reset();
        
        // Ensure unread count is updated if doctor sends a reply later
        populatePatientInfo();
        // Re-render the inbox to show the sent message immediately
        renderMessageInbox();
    }, 1500);
});

// Profile Update Form Logic (ENHANCED with Validation)
profileUpdateForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const profileStatus = document.getElementById('profile-status');
    
    // Reset status message
    profileStatus.classList.remove('hidden', 'text-danger', 'text-primary');

    const newName = document.getElementById('profile-name').value.trim();
    const newEmail = document.getElementById('profile-email').value.trim(); // Get email value
    const newPhone = document.getElementById('profile-phone').value.trim();
    const newPassword = document.getElementById('profile-password').value; 
    const confirmPassword = document.getElementById('profile-password-confirm').value; 

    // 1. Phone Number Validation 
    // Requires exactly 10 digits starting with 05
    const phonePattern = /^05[0-9]{8}$/;
    if (!phonePattern.test(newPhone)) {
         profileStatus.classList.add('text-danger');
         profileStatus.textContent = 'Error: Phone number must be 10 digits and start with 05 (e.g., 05xxxxxxxx).';
         setTimeout(() => profileStatus.classList.add('hidden'), 5000);
         return;
    }

    // 2. Name Validation 
    // Requires letters and spaces only
    const namePattern = /^[A-Za-z\s]+$/;
    if (!namePattern.test(newName)) {
         profileStatus.classList.add('text-danger');
         profileStatus.textContent = 'Error: Full Name must contain letters and spaces only.';
         setTimeout(() => profileStatus.classList.add('hidden'), 5000);
         return;
    }

    // ⭐ 3. Email Validation
    if (!validateEmail(newEmail)) {
         profileStatus.classList.add('text-danger');
         profileStatus.textContent = 'Error: Please enter a valid email address format (e.g., user@domain.com).';
         setTimeout(() => profileStatus.classList.add('hidden'), 5000);
         return;
    }

    // 4. Password Validation (Only validate if a new password is provided)
    if (newPassword || confirmPassword) {
        if (newPassword !== confirmPassword) {
            profileStatus.classList.add('text-danger');
            profileStatus.textContent = 'Error: New Password and Confirm Password do not match.';
            setTimeout(() => profileStatus.classList.add('hidden'), 5000);
            return;
        }
        
        // Check length (min 8 characters)
        if (newPassword.length < 8) {
            profileStatus.classList.add('text-danger');
            profileStatus.textContent = 'Error: Password must be at least 8 characters long.';
            setTimeout(() => profileStatus.classList.add('hidden'), 5000);
            return;
        }
        
        // Check for both letters and numbers
        const hasLetter = /[A-Za-z]/.test(newPassword);
        const hasNumber = /[0-9]/.test(newPassword);
        
        if (!hasLetter || !hasNumber) {
            profileStatus.classList.add('text-danger');
            profileStatus.textContent = 'Error: Password must include both letters and numbers.';
            setTimeout(() => profileStatus.classList.add('hidden'), 7000);
            return;
        }

        // Password is valid (in a real app, update password hash here)
    }
    
    // Clear password fields after (simulated) processing
    document.getElementById('profile-password').value = '';
    document.getElementById('profile-password-confirm').value = '';
    
    // --- Data Update (Simulation) ---
    const newAge = document.getElementById('profile-age').value;
    const newGender = document.getElementById('profile-gender').value;
    const newHeight = document.getElementById('profile-height').value;
    const newWeight = document.getElementById('profile-weight').value;

    patientData.name = newName;
    patientData.email = newEmail; 
    patientData.phone = newPhone; // Save clean string of numbers
    patientData.age = newAge;
    patientData.gender = newGender;
    patientData.height = `${newHeight} cm`;
    patientData.weight = `${newWeight} kg`;

    profileStatus.classList.add('text-primary');
    profileStatus.textContent = 'Saving profile changes...';
    
    setTimeout(() => {
        populatePatientInfo(); 
        profileStatus.textContent = 'Profile updated successfully!';
        profileStatus.classList.add('text-primary');
    }, 1000);
});


// Initial rendering on load
window.onload = function() {
    populatePatientInfo();
    renderReportHistory();
    
    // Simulate clicking the dashboard link to apply initial active styling
    const activeLink = document.querySelector('nav a[data-section="overview"]');
    if (activeLink) {
        activeLink.click();
    } else {
         document.querySelector('.content-section').classList.remove('hidden');
    }
};

// Logout Simulation
document.getElementById('logout-btn').addEventListener('click', () => {
    alert("Simulated: Patient session logged out successfully.");
    console.log("Patient logged out.");
});