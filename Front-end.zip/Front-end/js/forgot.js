document.addEventListener('DOMContentLoaded', () => {
    const forgotForm = document.getElementById('forgotForm');
    const emailInput = document.getElementById('email');
    const statusDiv = document.getElementById('forgot-status');

    // Helper function to show status message
    function showStatus(message, isError = false) {
        statusDiv.textContent = message;
        statusDiv.classList.remove('hidden', 'text-primary', 'text-danger');
        statusDiv.classList.add(isError ? 'text-danger' : 'text-primary');
    }

    forgotForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = emailInput.value.trim().toLowerCase();
        
        statusDiv.classList.add('hidden');

        if (!email) {
            showStatus('Please enter your email address.', true);
            return;
        }

        // Basic Email validation (no domain check)
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showStatus("Please enter a valid email address.", true);
            return;
        }

        // --- Simulate Email Sending ---
        
        showStatus(`If ${email} is registered, a password reset link has been sent. Check your inbox!`, false);
        
        console.log(`Simulated password reset request for: ${email}`);
        
        // Optionally clear the form
        forgotForm.reset();

        // Optionally hide the button to prevent double submissions
        // document.querySelector('button[type="submit"]').disabled = true;
    });
});