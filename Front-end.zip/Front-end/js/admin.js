// --- DATA SIMULATION (In a real app, this would be fetched from Firestore) ---
let users = [
    { id: 'usr-101', name: 'Dr. Ahmad Saleh', role: 'Doctor', email: 'ahmad.saleh@neuro.com' },
    { id: 'usr-102', name: 'Ms. Sarah Ali', role: 'Patient', email: 'sarah.ali@mail.com' },
    { id: 'usr-103', name: 'Dr. Maha Asiri', role: 'Doctor', email: 'maha.asiri@neuro.com' },
    { id: 'usr-104', name: 'Admin User', role: 'Admin', email: 'admin@system.com' },
    { id: 'usr-105', name: 'Mr. Khaled Zaki', role: 'Patient', email: 'khaled.zaki@mail.com' },
];

const activityData = [
    { time: '10:55 AM', id: 'usr-101', action: 'Uploaded new scan for Pat-502', status: 'Success' },
    { time: '10:48 AM', id: 'usr-103', action: 'Accessed Pat-401 Report', status: 'Success' },
    { time: '10:30 AM', id: 'usr-102', action: 'Logged in', status: 'Success' },
    { time: '10:25 AM', id: 'usr-599', action: 'Login Attempt (Failed)', status: 'Error' },
    { time: '10:20 AM', id: 'usr-104', action: 'Model Deploy Request', status: 'Pending' },
];

const systemLogs = [
    '[10:55:01] INFO: Scan uploaded to /uploads/usr-101/scn-20251110.dcm',
    '[10:55:05] MODEL: Analysis started for scn-20251110.dcm',
    '[10:55:12] DB: Query executed successfully (GET Report: RPT-401)',
    '[10:50:33] AUTH: User usr-102 logged in from IP 192.168.1.5',
    '[10:48:20] AUTH: User usr-103 logged in from IP 10.0.0.9',
    '[10:30:15] DB: Health check successful. Uptime: 45 days.',
    '[10:25:40] ERROR: Auth failure for user \'hacker\' (Invalid Password)',
    '[10:20:01] ADMIN: Model update pending approval for v4.0. Status: Awaiting Validation.',
    '[10:15:55] INFO: System metrics collected. Load: 0.85.',
];

// --- DOM ELEMENTS AND CONSTANTS ---
const sidebar = document.getElementById('sidebar');
const menuBtn = document.getElementById('menu-btn');
const pageTitle = document.getElementById('page-title');
const userListBody = document.getElementById('user-list');
const activityLogBody = document.getElementById('activity-log');
const logOutputDiv = document.getElementById('log-output');
const addUserModal = document.getElementById('addUserModal');
const messageModal = document.getElementById('messageModal');
const userForm = document.getElementById('user-form');
let isEditMode = false;
let editingUserId = null;

// --- HELPER FUNCTIONS ---

// Function to show custom message modal
function showMessage(title, content, isError = false) {
    document.getElementById('message-title').textContent = title;
    document.getElementById('message-content').textContent = content;
    // Updated text colors for dark theme
    const titleElement = document.getElementById('message-title');
    if (isError) {
        titleElement.classList.add('text-danger');
        titleElement.classList.remove('text-primary');
    } else {
        titleElement.classList.remove('text-danger');
        titleElement.classList.add('text-primary');
    }
    messageModal.showModal();
}

// Function to validate the password criteria
function validatePassword(password) {
    // Must be at least 8 characters
    if (password.length < 8) {
        return "Password must be at least 8 characters long.";
    }
    // Must include at least one letter and one number
    if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
        return "Password must include at least one letter and one number.";
    }
    return null; // Password is valid
}

// ⭐ NEW: Function to validate email format using a simple regex
function validateEmail(email) {
    // Basic regex pattern for email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return "Please enter a valid email address (e.g., user@domain.com).";
    }
    return null; // Email is valid
}

// --- RENDERING FUNCTIONS (Unchanged) ---

function renderActivityLog() {
    activityLogBody.innerHTML = activityData.map(log => `
        <tr class="${log.status === 'Error' ? 'bg-red-900/10' : log.status === 'Pending' ? 'bg-yellow-900/10' : 'bg-card-bg'} hover:bg-card-bg/50">
            <td class="px-4 py-2 whitespace-nowrap text-gray-400">${log.time}</td>
            <td class="px-4 py-2 whitespace-nowrap text-primary font-medium">${log.id}</td>
            <td class="px-4 py-2">${log.action}</td>
            <td class="px-4 py-2">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${log.status === 'Success' ? 'bg-primary/20 text-primary' : log.status === 'Error' ? 'bg-danger/20 text-danger' : 'bg-secondary/20 text-secondary'}">
                    ${log.status}
                </span>
            </td>
        </tr>
    `).join('');
}

function renderUserList(filteredUsers = users) {
    userListBody.innerHTML = filteredUsers.map(user => `
        <tr id="user-row-${user.id}" class="bg-card-bg hover:bg-card-bg/50">
            <td class="px-4 py-3 font-medium text-primary">${user.id}</td>
            <td class="px-4 py-3">${user.name}</td>
            <td class="px-4 py-3">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${user.role === 'Doctor' ? 'bg-blue-600/20 text-blue-300' : user.role === 'Admin' ? 'bg-danger/20 text-danger' : 'bg-gray-600/20 text-gray-300'}">
                    ${user.role}
                </span>
            </td>
            <td class="px-4 py-3 text-gray-400">${user.email}</td>
            <td class="px-4 py-3 whitespace-nowrap text-sm font-medium space-x-2">
                <button onclick="editUser('${user.id}')" class="text-primary hover:text-secondary transition">
                    Edit
                </button>
                <button onclick="deleteUser('${user.id}')" class="text-danger hover:text-red-400 transition">
                    Delete
                </button>
            </td>
        </tr>
    `).join('');
}

function renderSystemLogs() {
    logOutputDiv.innerHTML = systemLogs.map(log => {
        let color = 'text-gray-300';
        if (log.includes('ERROR')) color = 'text-danger font-semibold';
        else if (log.includes('ADMIN')) color = 'text-primary font-semibold';
        else if (log.includes('MODEL')) color = 'text-secondary';
        return `<div class="${color}">${log}</div>`;
    }).join('');
}


// --- USER MANAGEMENT LOGIC (CRUD Simulation) ---

// Open Modal in Edit Mode
function editUser(id) {
    const user = users.find(u => u.id === id);
    if (!user) return showMessage("Error", "User not found.", true);

    isEditMode = true;
    editingUserId = id;

    document.getElementById('modal-title').textContent = 'Edit User: ' + user.name;
    document.getElementById('user-name').value = user.name;
    document.getElementById('user-email').value = user.email;
    document.getElementById('user-role').value = user.role;

    // Hide password fields in edit mode
    document.getElementById('password-group').classList.add('hidden');
    document.getElementById('confirm-password-group').classList.add('hidden');
    document.getElementById('user-password').removeAttribute('required');
    document.getElementById('user-confirm-password').removeAttribute('required');

    addUserModal.showModal();
}

// Delete User Simulation (Unchanged)
function deleteUser(id) {
    // NOTE: Using window.confirm as a simulation for a custom dialog since alerts are disallowed.
    const confirmDeletion = window.confirm(`Are you sure you want to delete user ${id}? This action cannot be undone.`);
    if (!confirmDeletion) return;

    users = users.filter(u => u.id !== id);
    renderUserList();
    showMessage("Success", `User ${id} deleted successfully.`, false);
}

// ⭐ MODIFIED Form Submission Handler to include Email validation
userForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('user-name').value.trim();
    const email = document.getElementById('user-email').value.trim();
    const role = document.getElementById('user-role').value;
    // Password values are only checked/used during ADD
    const password = document.getElementById('user-password').value; 
    const confirmPassword = document.getElementById('user-confirm-password').value; 

    // 1. Name Validation (Letters and spaces only)
    if (!/^[a-zA-Z\s]+$/.test(name)) {
        return showMessage("Validation Error", "Full Name must contain only letters and spaces.", true);
    }
    
    // ⭐ 2. Email Format Validation
    const emailError = validateEmail(email);
    if (emailError) {
        return showMessage("Validation Error", emailError, true);
    }
    
    // 3. Existing User Check (Name or Email)
    const existingUser = users.find(u => 
        (u.name.toLowerCase() === name.toLowerCase() || u.email.toLowerCase() === email.toLowerCase()) && 
        u.id !== editingUserId // Exclude the current user when editing
    );

    if (existingUser) {
        let message = `Cannot ${isEditMode ? 'update' : 'add'} user. A user with the name '${name}' or email '${email}' already exists.`;
        return showMessage("Validation Error", message, true);
    }

    if (isEditMode) {
        // EDIT LOGIC (Name/Email/Role update only)
        const userIndex = users.findIndex(u => u.id === editingUserId);
        if (userIndex !== -1) {
            users[userIndex] = { ...users[userIndex], name, email, role };
            showMessage("Success", `User ${name} updated successfully.`, false);
        }
    } else {
        // ADD LOGIC
        
        // 4. Password Complexity Validation
        const passwordError = validatePassword(password);
        if (passwordError) {
            return showMessage("Validation Error", passwordError, true);
        }
        
        // 5. Confirm Password Match Check
        if (password !== confirmPassword) {
            return showMessage("Validation Error", "Password and Confirm Password must match.", true);
        }

        const newUser = {
            id: 'usr-' + (Math.floor(Math.random() * 900) + 100), // Simulate ID generation
            name: name,
            role: role,
            email: email,
            // Note: Password would typically be hashed and sent to a backend here.
        };
        users.push(newUser);
        showMessage("Success", `New user ${name} (${newUser.id}) created.`, false);
    }

    renderUserList();
    addUserModal.close();
    resetModal();
});
// ⭐ END MODIFIED Form Submission Handler

// Reset Modal State (Unchanged)
function resetModal() {
    isEditMode = false;
    editingUserId = null;
    userForm.reset();
    document.getElementById('modal-title').textContent = 'Add New User';
    
    // Show password fields and set required for add mode
    document.getElementById('password-group').classList.remove('hidden');
    document.getElementById('confirm-password-group').classList.remove('hidden');
    document.getElementById('user-password').setAttribute('required', 'required');
    document.getElementById('user-confirm-password').setAttribute('required', 'required');
    
    // Clear password values
    document.getElementById('user-password').value = ''; 
    document.getElementById('user-confirm-password').value = '';
}

// User Search Functionality (Unchanged)
document.getElementById('user-search').addEventListener('input', function(e) {
    const query = e.target.value.toLowerCase();
    const filtered = users.filter(user =>
        user.id.toLowerCase().includes(query) ||
        user.name.toLowerCase().includes(query) ||
        user.role.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query)
    );
    renderUserList(filtered);
});

// --- AI MODEL CONFIGURATION LOGIC (Unchanged) ---
document.getElementById('model-upload-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const file = document.getElementById('model-file').files[0];
    const newVersion = document.getElementById('new-version').value;
    const changelog = document.getElementById('changelog').value;
    const uploadStatus = document.getElementById('upload-status');

    if (!file) {
        return showMessage("Error", "Please select an AI model file to upload.", true);
    }

    uploadStatus.classList.remove('hidden', 'text-danger', 'text-primary');
    uploadStatus.classList.add('text-secondary');
    uploadStatus.textContent = 'Uploading model...';

    // Simulate file upload and deployment delay
    setTimeout(() => {
        // Success simulation
        document.getElementById('model-version').textContent = newVersion;
        document.getElementById('model-date').textContent = new Date().toLocaleString();
        document.getElementById('model-status').textContent = '96.3% (Simulated)';

        uploadStatus.textContent = `Model ${newVersion} deployed successfully!`;
        uploadStatus.classList.remove('text-secondary');
        uploadStatus.classList.add('text-primary');

        showMessage("Deployment Complete", `AI Model updated to version ${newVersion}. Changelog: ${changelog}`, false);
        document.getElementById('model-upload-form').reset();
    }, 2500); // 2.5 second delay
});

// --- NAVIGATION & INIT (Unchanged) ---

// Mobile Menu Toggle
menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('-translate-x-full');
});

// Navigation Handler
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();

        const targetSectionId = this.getAttribute('data-section');
        const targetSection = document.getElementById(targetSectionId);

        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.add('hidden');
        });

        // Show target section
        if (targetSection) {
            targetSection.classList.remove('hidden');
            pageTitle.textContent = this.textContent;
        }

        // Update active link styling
        document.querySelectorAll('nav a').forEach(nav => nav.classList.remove('bg-primary/30', 'active-link'));
        this.classList.add('bg-primary/30', 'active-link');

        // Hide mobile menu after selection
        if (window.innerWidth < 768) {
            sidebar.classList.add('-translate-x-full');
        }
    });
});

// Initial rendering on load
window.onload = function() {
    renderActivityLog();
    renderUserList();
    renderSystemLogs();

    // Simulate click on the default dashboard link to set initial state
    document.querySelector('.active-link').click();
};

// Logout Simulation
document.getElementById('logout-btn').addEventListener('click', () => {
    showMessage("Logout", "Admin session logged out successfully.", false);
    // In a real application, this would redirect to the login page.
    console.log("Admin logged out.");
});