// js/doctor-dashboard.js

// --- Data Simulation (Replace with actual API calls in production) ---
const DOCTOR_DATA = {
    name: "Dr. Kiran Patel",
    id: "D-9014567",
    email: "dr.patel@neuroscan.ai",
    phone: "0501234567", // Updated to follow validation rule
    specialty: "Neuro-Radiology",
    hospital: "King Faisal Specialist",
    pendingReportsCount: 12,
    unreadMessagesCount: 5
};

const SIMULATED_REPORTS = [
    { id: 'RPT-008', patientId: 'P-4011234', patientName: 'Fahad Al-Mubarak', date: 'Nov 11, 2025', finding: 'Tumor', probability: '95%', status: 'Pending Review' },
    { id: 'RPT-007', patientId: 'P-5590401', patientName: 'Fatima Saeed', date: 'Nov 10, 2025', finding: 'Suspicious Lesion', probability: '78%', status: 'Pending Review' },
    { id: 'RPT-005', patientId: 'P-4438123', patientName: 'Mohammad Naif', date: 'Apr 10, 2025', finding: 'Tumor', probability: '91%', status: 'Finalized' },
];

const SIMULATED_MESSAGES = [
    { id: 'MSG-005', sender: 'Mohammad Naif', date: 'Nov 12, 2025', subject: 'Question about Report RPT-005', body: 'Dear Doctor Patel,\nI received the report and was concerned about the 91% probability finding. Can we schedule a quick call to discuss the next steps for the suggested biopsy? Thank you.', isRead: false },
    { id: 'MSG-004', sender: 'Laila Hassan', date: 'Oct 30, 2025', subject: 'Follow-up Scan OK', body: 'Just confirming I received my normal scan results. Thank you for the quick turnaround!', isRead: true },
];

// NEW: Simulated Patient Data for Profile View (including Age, Gender, Height, Weight)
const SIMULATED_PATIENTS = [
    { id: 'P-4438123', name: 'Mohammad Naif', age: 45, gender: 'Male', height: '175 cm', weight: '80 kg' },
    { id: 'P-5590401', name: 'Laila Hassan', age: 32, gender: 'Female', height: '163 cm', weight: '65 kg' },
    { id: 'P-4011234', name: 'Fahad Al-Mubarak', age: 60, gender: 'Male', height: '185 cm', weight: '95 kg' },
];

// ⭐ NEW HELPER FUNCTION FOR EMAIL VALIDATION
function validateEmail(email) {
    // Basic regex pattern for email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
// ⭐ END NEW HELPER FUNCTION

// --- Core SPA Navigation Logic ---
function navigateToSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(sec => {
        sec.classList.add('hidden');
    });
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.remove('hidden');
    }

    // Update title
    let titleElement = document.querySelector(`[data-section="${sectionId}"] span`);
    if(titleElement) {
        document.getElementById('page-title').textContent = titleElement.textContent;
    }

    // Update active link in sidebar
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active-link', 'bg-primary/30');
        link.classList.remove('bg-primary/50'); // Ensure no hover state persists
    });
    const activeLink = document.querySelector(`[data-section="${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active-link', 'bg-primary/30');
    }

    // Close sidebar on mobile after navigation
    const sidebar = document.getElementById('sidebar');
    if (sidebar.classList.contains('open')) {
        sidebar.classList.remove('open');
    }
}

// --- Data Population Functions ---

function loadDashboardData() {
    document.getElementById('total-patients').textContent = '145'; // Simulated static number
    document.getElementById('total-scans').textContent = '589'; // Simulated static number
    document.getElementById('pending-reports').textContent = DOCTOR_DATA.pendingReportsCount;
    document.getElementById('unread-messages').textContent = DOCTOR_DATA.unreadMessagesCount;
    document.getElementById('unread-count').textContent = DOCTOR_DATA.unreadMessagesCount;
}

function loadReportsHistory() {
    const tableBody = document.getElementById('full-reports-list');
    if (!tableBody) return;
    // (Implementation relies on pre-filled HTML for simplicity)
}

function loadMessagesInbox() {
    const tableBody = document.getElementById('doctor-message-inbox-body');
    if (!tableBody) return;

    // UPDATED: Changed button text from "View/Reply" to "View"
    tableBody.innerHTML = SIMULATED_MESSAGES.map(msg => `
        <tr class="hover:bg-primary/10 transition cursor-pointer ${msg.isRead ? '' : 'font-bold bg-white/5'}" data-msg-id="${msg.id}">
            <td class="px-4 py-2">${msg.sender}</td>
            <td class="px-4 py-2 text-primary">${msg.subject}</td>
            <td class="px-4 py-2">${msg.date}</td>
            <td class="px-4 py-2"><button onclick="viewMessageDetails('${msg.id}')" class="text-primary hover:text-secondary">View</button></td>
        </tr>
    `).join('');
}

function loadProfileData() {
    document.getElementById('doc-profile-name').value = DOCTOR_DATA.name;
    document.getElementById('doc-profile-id').value = DOCTOR_DATA.id;
    document.getElementById('doc-profile-email').value = DOCTOR_DATA.email;
    document.getElementById('doc-profile-phone').value = DOCTOR_DATA.phone;
    document.getElementById('doc-profile-specialty').value = DOCTOR_DATA.specialty;
    document.getElementById('doc-profile-hospital').value = DOCTOR_DATA.hospital;
    
    // Update sidebar snippet
    document.getElementById('doctor-name').textContent = DOCTOR_DATA.name;
    document.getElementById('doctor-id').textContent = `ID: ${DOCTOR_DATA.id}`;
}

// --- Modal Functions ---

window.viewReportDetails = (reportId) => {
    const report = SIMULATED_REPORTS.find(r => r.id === reportId) || {};
    const modal = document.getElementById('reportModal');
    
    document.getElementById('report-modal-title').textContent = `Diagnostic Report (${reportId})`;
    document.getElementById('report-patient-id').textContent = report.patientId || 'N/A';
    document.getElementById('report-date').textContent = report.date || 'N/A';
    document.getElementById('report-summary').textContent = `Automated interpretation found a ${report.finding ? report.finding.toLowerCase() : 'finding'} with ${report.probability || 'N/A'} confidence.`;
    
    // Mocking confidence breakdown for the modal
    const confidenceList = document.getElementById('report-confidence');
    const probability = parseInt(report.probability.replace('%', ''));
    confidenceList.innerHTML = `
        <li>${report.finding || 'Finding'}: ${report.probability || 'N/A'}</li>
        <li>No finding: ${isNaN(probability) ? 'N/A' : (100 - probability) + '%'}</li>
    `;

    modal.showModal();
};

window.viewMessageDetails = (messageId) => {
    const message = SIMULATED_MESSAGES.find(m => m.id === messageId);
    if (!message) return;

    const modal = document.getElementById('messageModal');
    document.getElementById('msg-sender').textContent = message.sender;
    document.getElementById('msg-date').textContent = message.date;
    document.getElementById('msg-subject').textContent = message.subject;
    document.getElementById('msg-body').textContent = message.body;

    modal.showModal();

    // Mark as read (simulated)
    message.isRead = true;
    DOCTOR_DATA.unreadMessagesCount = SIMULATED_MESSAGES.filter(m => !m.isRead).length;
    loadMessagesInbox(); // Reload the inbox to update styling
    loadDashboardData(); // Update unread count
};

// Function to display Patient Profile
window.viewPatientProfile = (patientId) => {
    const patient = SIMULATED_PATIENTS.find(p => p.id === patientId);
    const modal = document.getElementById('patientProfileModal');

    if (!patient) {
        alert(`Patient with ID ${patientId} not found. (Simulated Data Error)`);
        return;
    }

    // Populate profile details
    document.getElementById('profile-patient-name').textContent = patient.name;
    document.getElementById('profile-patient-id').textContent = patient.id;
    document.getElementById('profile-patient-age').textContent = patient.age;
    document.getElementById('profile-patient-gender').textContent = patient.gender;
    document.getElementById('profile-patient-height').textContent = patient.height;
    document.getElementById('profile-patient-weight').textContent = patient.weight;

    modal.showModal();
};


// --- Event Listeners and Validation Logic ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initial Data Load
    loadDashboardData();
    loadReportsHistory();
    loadMessagesInbox();
    loadProfileData();

    // 2. Attach Navigation Listeners
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            navigateToSection(section);
        });
    });

    // 3. Mobile Menu Toggle
    const menuBtn = document.getElementById('menu-btn');
    const sidebar = document.getElementById('sidebar');
    menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('open');
    });

    // 4. Form Submission (Simulated)
    
    // Patient Profile Update Form Validation and Submission
    document.getElementById('doctor-profile-update-form')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const form = e.target;
        const status = document.getElementById('doc-profile-status');
        const newPassword = document.getElementById('doc-profile-password').value;
        const confirmPassword = document.getElementById('doc-profile-password-confirm').value;
        const email = document.getElementById('doc-profile-email').value; // Get email value
        
        status.classList.remove('hidden', 'text-green-400', 'text-danger');

        // Check standard HTML5 pattern validation first (for Name, Phone, Specialty, Hospital)
        if (!form.checkValidity()) {
             status.classList.add('text-danger');
             status.textContent = 'Error: Please check the highlighted fields for correct format/value.';
             setTimeout(() => status.classList.add('hidden'), 5000);
             return;
        }

        // ⭐ NEW: Email Validation Check
        if (!validateEmail(email)) {
            status.classList.add('text-danger');
            status.textContent = 'Error: Please enter a valid email address format (e.g., user@domain.com).';
            setTimeout(() => status.classList.add('hidden'), 5000);
            return;
        }

        // --- Custom Password Match Validation ---
        if (newPassword || confirmPassword) {
            // Password fields are optional, but if one is filled, the other must match
            if (newPassword !== confirmPassword) {
                status.classList.add('text-danger');
                status.textContent = 'Error: New Password and Confirm Password do not match.';
                setTimeout(() => status.classList.add('hidden'), 5000);
                return;
            }
            // Password content (8+ chars, letters/numbers) is handled by the HTML pattern attribute
        }

        // --- Data Update (Simulation) ---
        DOCTOR_DATA.name = document.getElementById('doc-profile-name').value;
        DOCTOR_DATA.email = email; // Use the validated email
        DOCTOR_DATA.phone = document.getElementById('doc-profile-phone').value;
        DOCTOR_DATA.specialty = document.getElementById('doc-profile-specialty').value;
        DOCTOR_DATA.hospital = document.getElementById('doc-profile-hospital').value;
        
        // Reset password fields after successful update
        document.getElementById('doc-profile-password').value = '';
        document.getElementById('doc-profile-password-confirm').value = '';

        // Final Success Message
        status.classList.add('text-green-400');
        status.textContent = 'Profile updated successfully!';
        
        // Reload sidebar data
        loadProfileData(); 
        
        setTimeout(() => status.classList.add('hidden'), 3000);
    });
    
    // Upload MRI Form Validation and Submission
    document.getElementById('upload-form')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const form = e.target;
        const status = document.getElementById('upload-status');
        const fileInput = document.getElementById('mri-file-input');

        status.classList.remove('hidden', 'text-danger', 'text-green-400');
        
        // Check standard HTML5 pattern validation first (for Patient ID)
        if (!form.checkValidity()) {
             status.classList.add('text-danger');
             status.textContent = 'Error: Please ensure the Patient ID is in the P-XXXXXXX format.';
             setTimeout(() => status.classList.add('hidden'), 5000);
             return;
        }

        // --- Custom File Type Validation (for better user message) ---
        const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.dcm|\.dicom)$/i;
        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            if (!allowedExtensions.exec(fileName)) {
                status.classList.add('text-danger');
                status.textContent = 'Error: Only DICOM, JPG, and PNG files are allowed.';
                setTimeout(() => status.classList.add('hidden'), 5000);
                return;
            }
        } else {
             status.classList.add('text-danger');
             status.textContent = 'Error: Please select a file to upload.';
             setTimeout(() => status.classList.add('hidden'), 5000);
             return;
        }


        // If all validation passes
        status.classList.add('text-green-400');
        status.textContent = 'MRI Scan submitted for AI analysis successfully! Report expected within 1 hour.';
        e.target.reset(); // Clear form
        setTimeout(() => status.classList.add('hidden'), 4000);
    });
    
    // Doctor Contact Form Submission
    document.getElementById('doctor-contact-form')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const status = document.getElementById('doctor-contact-status');
        status.classList.remove('hidden', 'text-danger');
        status.classList.add('text-green-400');
        status.textContent = `Message sent securely to ${document.getElementById('patient-select').value}!`;
        e.target.reset(); // Clear form
        setTimeout(() => status.classList.add('hidden'), 3000);
    });

    // 5. Initial view (Dashboard)
    navigateToSection('dashboard');

});