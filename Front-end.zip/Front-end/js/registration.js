document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registrationForm');
    const statusDiv = document.getElementById('registration-status');

    // Get input and error elements
    const fullNameInput = document.getElementById('fullName');
    const mobileInput = document.getElementById('mobile');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');

    const fullNameError = document.getElementById('fullNameError');
    const mobileError = document.getElementById('mobileError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');

    // Helper function to show status message (general error/success)
    function showStatus(message, isError = false) {
        statusDiv.textContent = message;
        statusDiv.classList.remove('hidden', 'text-primary', 'text-danger');
        statusDiv.classList.add(isError ? 'text-danger' : 'text-primary');
    }

    // Helper function to show specific field error
    function showFieldError(element, message) {
        element.textContent = message;
        element.classList.remove('hidden');
    }

    // Helper function to hide specific field error
    function hideFieldError(element) {
        element.classList.add('hidden');
        element.textContent = '';
    }

    registrationForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // Clear all previous errors
        showStatus('', false); 
        hideFieldError(fullNameError);
        hideFieldError(mobileError);
        hideFieldError(passwordError);
        hideFieldError(confirmPasswordError);

        const fullName = fullNameInput.value.trim();
        const email = document.getElementById('email').value.trim();
        const mobile = mobileInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();
        const role = document.querySelector('input[name="role"]:checked')?.value;
        
        let isValid = true;

        // 1. Full Name Validation (Letters, spaces, hyphens only)
        const namePattern = /^[a-zA-Z\s\-]+$/; 
        if (!namePattern.test(fullName)) {
            showFieldError(fullNameError, "Name must contain only letters, spaces, or hyphens.");
            isValid = false;
        }

        // 2. Mobile Number Validation (10 digits, starts with 05)
        const mobilePattern = /^05\d{8}$/; 
        if (!mobilePattern.test(mobile)) {
            showFieldError(mobileError, "Mobile must be 10 digits and start with '05'.");
            isValid = false;
        }
        
        // 3. Email validation (Basic format check)
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showStatus("Please enter a valid email address.", true);
            isValid = false;
        }

        // 4. Password Strength Validation (Min 8 chars, including letters and numbers)
        const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        if (!passwordPattern.test(password)) {
            showFieldError(passwordError, "Password must be min 8 characters and include both letters and numbers.");
            isValid = false;
        }
        
        // 5. Confirm Password Validation (Must match password)
        if (password !== confirmPassword) {
            showFieldError(confirmPasswordError, "Passwords do not match.");
            isValid = false;
        }

        // Stop submission if any validation failed
        if (!isValid) {
            // A general status message is shown for attention
            if (statusDiv.classList.contains('hidden')) {
                showStatus("Please correct the highlighted errors.", true);
            }
            return;
        }
        
        // --- If all validation passes, simulate successful registration ---
        
        showStatus(`Registration successful for ${fullName} as ${role}! Redirecting to login...`, false);

        // Log data (for debugging/backend simulation)
        console.log('Form Data Submitted for registration:', { fullName, email, mobile, password, role });

        // Simulate redirection after a delay
        setTimeout(() => {
            registrationForm.reset();
            // window.location.href = 'login.html'; // Uncomment to enable actual redirection
        }, 1500);
    });
});