const path = require('path');

// runModel: تستقبل مسار الصورة وترجع النتيجة من Python
function runModel(imagePath) {
  return new Promise((resolve, reject) => {
    try {
      // TODO: ربط ملف data.py هنا
      // في الوقت الحالي نرجع نتيجة وهمية للاختبار
      const result = {
        success: true,
        imagePath: imagePath,
        analysis: {
          hasTumor: false,
          confidence: 0.95,
          message: 'صورة سليمة - لا يوجد ورم'
        }
      };
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}

module.exports = { runModel };