const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");

// رفع الصور وتخزينها في مجلد uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// استدعاء كود تشغيل الموديل
const { runModel } = require("./runModel");

// API: استلام صورة وتشغيل الموديل عليها
router.post("/analyze", upload.single("file"), async (req, res) => {
  try {
    const imagePath = req.file.path;

    // تشغيل الموديل
    const result = await runModel(imagePath);

    res.json({ result });
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: "Model processing failed" });
  }
});

module.exports = router;