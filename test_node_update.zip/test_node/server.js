const express = require('express');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// تكوين multer لرفع الملفات
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  }
});

const upload = multer({ storage: storage });

// جعل مجلد public متاحاً للاستخدام
app.use(express.static(path.join(__dirname, "public")));

// Routes
const analyzeRoutes = require("./routes/analyze");
app.use("/api", analyzeRoutes);

// Route الرئيسية
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// تشغيل السيرفر
app.listen(PORT, () => {
  console.log('='.repeat(60));
  console.log('🧠 BRAIN TUMOR DETECTION SYSTEM - MAIN SERVER');
  console.log('='.repeat(60));
  console.log(`✅ Server: http://localhost:${PORT}`);
  console.log(`✅ API: http://localhost:${PORT}/api/analyze`);
  console.log(`✅ Frontend: http://localhost:${PORT}`);
  console.log('='.repeat(60));
});
