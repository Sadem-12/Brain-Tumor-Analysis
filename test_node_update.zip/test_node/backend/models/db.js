// backend/models/db.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../mri_system.db');
const db = new sqlite3.Database(dbPath);

// Export للاستخدام في كل مكان
module.exports = db;