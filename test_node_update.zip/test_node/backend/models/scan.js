// backend/models/scan.js
const db = require('../config/database');

class Scan {
    // إنشاء فحص جديد
    static create(scanData) {
        return new Promise((resolve, reject) => {
            const sql = `
                INSERT INTO scans (patient_id, image_path, original_filename, notes) 
                VALUES (?, ?, ?, ?)
            `;
            
            const params = [
                scanData.patient_id || null,
                scanData.image_path,
                scanData.original_filename,
                scanData.notes || ''
            ];
            
            db.run(sql, params, function(err) {
                if (err) {
                    console.error('Scan create error:', err);
                    reject(err);
                } else {
                    resolve({ 
                        id: this.lastID, 
                        ...scanData 
                    });
                }
            });
        });
    }
    
    // البحث بالـID
    static findById(id) {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT s.*, 
                       u.full_name as patient_name,
                       u.email as patient_email
                FROM scans s
                LEFT JOIN patients p ON s.patient_id = p.id
                LEFT JOIN users u ON p.user_id = u.id
                WHERE s.id = ?
            `;
            
            db.get(sql, [id], (err, row) => {
                if (err) {
                    console.error('Scan findById error:', err);
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }
    
    // جلب فحوصات مريض
    static getByPatient(patientId) {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT s.*, 
                       a.has_tumor, 
                       a.confidence,
                       a.analyzed_at
                FROM scans s
                LEFT JOIN analyses a ON s.id = a.scan_id
                WHERE s.patient_id = ?
                ORDER BY s.upload_date DESC
            `;
            
            db.all(sql, [patientId], (err, rows) => {
                if (err) {
                    console.error('Scan getByPatient error:', err);
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }
    
    // جلب كل الفحوصات (للمسؤول)
    static getAll() {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT s.*, 
                       u.full_name as patient_name,
                       a.has_tumor,
                       a.confidence
                FROM scans s
                LEFT JOIN patients p ON s.patient_id = p.id
                LEFT JOIN users u ON p.user_id = u.id
                LEFT JOIN analyses a ON s.id = a.scan_id
                ORDER BY s.upload_date DESC
            `;
            
            db.all(sql, [], (err, rows) => {
                if (err) {
                    console.error('Scan getAll error:', err);
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }
    
    // تحديث حالة الفحص
    static updateStatus(id, status) {
        return new Promise((resolve, reject) => {
            const sql = `
                UPDATE scans 
                SET status = ?, 
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            `;
            
            db.run(sql, [status, id], function(err) {
                if (err) {
                    console.error('Scan updateStatus error:', err);
                    reject(err);
                } else {
                    resolve({ 
                        changes: this.changes,
                        id: id,
                        status: status 
                    });
                }
            });
        });
    }
    
    // حذف فحص
    static delete(id) {
        return new Promise((resolve, reject) => {
            const sql = `DELETE FROM scans WHERE id = ?`;
            
            db.run(sql, [id], function(err) {
                if (err) {
                    console.error('Scan delete error:', err);
                    reject(err);
                } else {
                    resolve({ 
                        changes: this.changes,
                        id: id 
                    });
                }
            });
        });
    }
}

module.exports = Scan;