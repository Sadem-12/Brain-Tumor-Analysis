// backend/models/user.js
const db = require('../config/database');

class User {
    // إنشاء مستخدم جديد
    static create(userData) {
        return new Promise((resolve, reject) => {
            const sql = `
                INSERT INTO users (username, password, email, role, full_name, phone) 
                VALUES (?, ?, ?, ?, ?, ?)
            `;
            const params = [
                userData.username,
                userData.password,
                userData.email,
                userData.role || 'patient',
                userData.full_name,
                userData.phone
            ];
            
            db.run(sql, params, function(err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, ...userData });
            });
        });
    }
    
    // البحث بالاسم
    static findByUsername(username) {
        return new Promise((resolve, reject) => {
            db.get(
                `SELECT id, username, password, email, role, full_name, phone, status 
                 FROM users WHERE username = ?`,
                [username],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }
    
    // جلب جميع المستخدمين
    static getAll() {
        return new Promise((resolve, reject) => {
            db.all(
                `SELECT id, username, email, role, full_name, status, created_at 
                 FROM users ORDER BY created_at DESC`,
                [],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }
    
    // جلب مستخدم بالـID
    static findById(id) {
        return new Promise((resolve, reject) => {
            db.get(
                `SELECT id, username, email, role, full_name, phone, status 
                 FROM users WHERE id = ?`,
                [id],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }
    
    // تحديث المستخدم
    static update(id, userData) {
        return new Promise((resolve, reject) => {
            const sql = `
                UPDATE users 
                SET email = ?, full_name = ?, phone = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            `;
            db.run(sql, [userData.email, userData.full_name, userData.phone, id], function(err) {
                if (err) reject(err);
                else resolve({ changes: this.changes });
            });
        });
    }
    
    // حذف المستخدم
    static delete(id) {
        return new Promise((resolve, reject) => {
            db.run(`DELETE FROM users WHERE id = ?`, [id], function(err) {
                if (err) reject(err);
                else resolve({ changes: this.changes });
            });
        });
    }
}

module.exports = User;