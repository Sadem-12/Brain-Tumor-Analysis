// backend/models/patient.js
const db = require('../config/database');

class Patient {
    static create(patientData) {
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO patients (user_id, age, gender, address, emergency_contact) 
                 VALUES (?, ?, ?, ?, ?)`,
                [
                    patientData.user_id,
                    patientData.age,
                    patientData.gender,
                    patientData.address,
                    patientData.emergency_contact
                ],
                function(err) {
                    if (err) reject(err);
                    else resolve({ id: this.lastID });
                }
            );
        });
    }
    
    static getAll() {
        return new Promise((resolve, reject) => {
            db.all(`
                SELECT p.*, u.username, u.email, u.full_name, u.phone 
                FROM patients p
                LEFT JOIN users u ON p.user_id = u.id
                ORDER BY p.id DESC
            `, [], (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
}

module.exports = Patient;