const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
    patient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Patient',
        required: [true, 'يجب إدخال بيانات المريض']
    },
    scan: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Scan',
        required: [true, 'يجب إدخال صورة المسح']
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'يجب معرفة الطبيب المسؤول']
    },
    
    // نتائج التحليل
    analysisResults: {
        hasTumor: {
            type: Boolean,
            default: false
        },
        tumorType: {
            type: String,
            enum: ['benign', 'malignant', 'none', 'unknown'],
            default: 'unknown'
        },
        confidenceLevel: {
            type: Number,
            min: 0,
            max: 100,
            default: 0
        },
        location: {
            x: Number,
            y: Number,
            z: Number
        },
        size: {
            type: Number, // حجم الورم بالميليمتر
            default: 0
        },
        notes: String // ملاحظات إضافية
    },
    
    // معلومات التقرير
    diagnosis: {
        type: String,
        required: [true, 'يجب إدخال التشخيص']
    },
    recommendations: {
        type: String,
        required: [true, 'يجب إدخال التوصيات الطبية']
    },
    medications: [{
        name: String,
        dosage: String,
        frequency: String
    }],
    
    // مواعيد المتابعة
    followUpDate: {
        type: Date
    },
    
    // حالة التقرير
    status: {
        type: String,
        enum: ['draft', 'reviewed', 'approved', 'sent'],
        default: 'draft'
    },
    
    // معلومات إضافية
    attachments: [{
        name: String,
        url: String,
        type: String
    }]
    
}, {
    timestamps: true // يضيف created_at و updated_at تلقائياً
});

// فهارس للبحث السريع
reportSchema.index({ patient: 1, createdAt: -1 });
reportSchema.index({ createdBy: 1 });
reportSchema.index({ 'analysisResults.hasTumor': 1 });

const Report = mongoose.model('Report', reportSchema);

module.exports = Report;