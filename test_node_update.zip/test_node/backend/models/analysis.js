// backend/models/analysis.js
const db = require('../config/database');

class Analysis {
    static create(analysisData) {
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO analyses (scan_id, has_tumor, confidence, tumor_type, tumor_size, notes) 
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    analysisData.scan_id,
                    analysisData.has_tumor ? 1 : 0,
                    analysisData.confidence,
                    analysisData.tumor_type,
                    analysisData.tumor_size,
                    analysisData.notes || ''
                ],
                function(err) {
                    if (err) reject(err);
                    else resolve({ id: this.lastID, ...analysisData });
                }
            );
        });
    }
    
    static getRecent(limit = 10) {
        return new Promise((resolve, reject) => {
            db.all(
                `SELECT a.*, s.original_filename, u.full_name as patient_name
                 FROM analyses a
                 JOIN scans s ON a.scan_id = s.id
                 LEFT JOIN patients p ON s.patient_id = p.id
                 LEFT JOIN users u ON p.user_id = u.id
                 ORDER BY a.analyzed_at DESC
                 LIMIT ?`,
                [limit],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }
}

module.exports = Analysis;