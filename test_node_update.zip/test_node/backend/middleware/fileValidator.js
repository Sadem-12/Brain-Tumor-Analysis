// backend/middleware/fileValidator.js
const multer = require('multer');
const path = require('path');

// إعدادات رفع الملفات
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueName + path.extname(file.originalname));
    }
});

// تصفية أنواع الملفات
const fileFilter = (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|dcm/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
        cb(null, true);
    } else {
        cb(new Error('Only MRI images (JPG, PNG, DCM) are allowed'));
    }
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB
        files: 1
    }
});

// Middleware للتحقق من الملفات
const validateFile = (req, res, next) => {
    if (!req.file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }
    
    // التحقق من حجم الملف
    if (req.file.size > 10 * 1024 * 1024) {
        return res.status(400).json({
            success: false,
            message: 'File size exceeds 10MB limit'
        });
    }
    
    // التحقق من نوع الملف
    const allowedTypes = ['.jpg', '.jpeg', '.png', '.dcm'];
    const fileExt = path.extname(req.file.originalname).toLowerCase();
    
    if (!allowedTypes.includes(fileExt)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid file type. Allowed: JPG, PNG, DCM'
        });
    }
    
    next();
};

module.exports = { upload, validateFile };