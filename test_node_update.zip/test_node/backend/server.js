const express = require("express");
const path = require("path");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// ========================
// 📦 MIDDLEWARE
// ========================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "../frontend")));
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

// ========================
// 🗄️ DATABASE INIT
// ========================
const connectDB = require("./config/db");
connectDB();

// ========================
// 🔗 ROUTES
// ========================
const authRoutes = require("./routes/authRoutes");
const analyzeRoutes = require("./routes/analyzeRoutes");

app.use("/api/auth", authRoutes);
app.use("/api/analyze", analyzeRoutes);

// ========================
// 🧪 HEALTH CHECK
// ========================
app.get("/api/health", (req, res) => {
    res.json({
        status: "healthy",
        service: "Brain Tumor Detection System",
        version: "1.0.0",
        timestamp: new Date().toISOString(),
        endpoints: [
            "POST /api/auth/login",
            "POST /api/auth/register",
            "POST /api/analyze/upload",
            "POST /api/analyze/:scanId/analyze"
        ]
    });
});

// ========================
// 🏠 FRONTEND PAGES
// ========================
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend", "index.html"));
});

app.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend", "login.html"));
});

app.get("/dashboard", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend", "dashboard.html"));
});

// ========================
// ⚡ ERROR HANDLING
// ========================
app.use((err, req, res, next) => {
    console.error("Error:", err.message);
    
    if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({
            success: false,
            message: "File size exceeds 10MB limit"
        });
    }
    
    res.status(500).json({
        success: false,
        message: "Internal server error",
        error: process.env.NODE_ENV === "development" ? err.message : undefined
    });
});

// ========================
// 🚀 START SERVER
// ========================
app.listen(PORT, () => {
    console.log("=".repeat(60));
    console.log("🧠 BRAIN TUMOR DETECTION SYSTEM");
    console.log("=".repeat(60));
    console.log(`✅ Server: http://localhost:${PORT}`);
    console.log(`✅ Health: http://localhost:${PORT}/api/health`);
    console.log(`✅ Uploads: http://localhost:${PORT}/uploads`);
    console.log("");
    console.log("🔐 Test Credentials:");
    console.log("   Username: admin");
    console.log("   Password: admin123");
    console.log("=".repeat(60));
});