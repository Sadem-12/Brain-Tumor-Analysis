// backend/routes/adminRoutes.js
const express = require("express");
const router = express.Router();

// Middleware للتحقق من صلاحيات المدير
const isAdmin = (req, res, next) => {
    // في الواقع: تتحقق من JWT token
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.includes("admin-token")) {
        return res.status(403).json({ 
            success: false, 
            message: "Admin access required" 
        });
    }
    next();
};

// إحصائيات النظام
router.get("/stats", isAdmin, (req, res) => {
    const stats = {
        totalAnalyses: 248,
        totalPatients: 156,
        tumorCases: 42,
        normalCases: 206,
        accuracyRate: "96.3%",
        recentActivity: [
            { id: 1, action: "MRI Analysis", user: "د. أحمد", time: "2 hours ago" },
            { id: 2, action: "New Patient", user: "ممرضة سارة", time: "4 hours ago" },
            { id: 3, action: "Report Generated", user: "System", time: "Yesterday" }
        ]
    };
    
    res.json({
        success: true,
        ...stats
    });
});

// قائمة كل المستخدمين
router.get("/users", isAdmin, (req, res) => {
    const users = [
        { id: 1, name: "د. أحمد علي", role: "doctor", email: "ahmed@hospital.com", status: "active" },
        { id: 2, name: "د. سارة محمد", role: "doctor", email: "sara@hospital.com", status: "active" },
        { id: 3, name: "محمد خالد", role: "patient", email: "mohamed@example.com", status: "active" }
    ];
    
    res.json({
        success: true,
        users: users,
        count: users.length
    });
});

module.exports = router;