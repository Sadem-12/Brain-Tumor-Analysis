// backend/routes/authRoutes.js
const express = require('express');
const router = express.Router();
const authController = require('../auth/authController');
const authMiddleware = require('../auth/authMiddleware');

// 🔐 Public Routes
router.post('/login', authController.login);
router.post('/register', authController.register);

// 🔒 Protected Routes (require token)
router.get('/profile', 
    authMiddleware.verifyToken, 
    authController.getProfile
);

// 👑 Admin only
router.get('/admin/users',
    authMiddleware.verifyToken,
    authMiddleware.checkRole(['admin']),
    async (req, res) => {
        try {
            const User = require('../models/user');
            const users = await User.getAll();
            res.json({ success: true, users });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }
);

module.exports = router;