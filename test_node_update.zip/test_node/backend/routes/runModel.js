// backend/routes/runModel.js
const express = require("express");
const { spawn } = require("child_process");
const path = require("path");
const router = express.Router();

// تشغيل Python model للتنبؤ
router.post("/predict", (req, res) => {
    const { imagePath } = req.body;
    
    if (!imagePath) {
        return res.status(400).json({ 
            success: false, 
            message: "Image path is required" 
        });
    }
    
    console.log("🧠 Running Python model for:", imagePath);
    
    // تشغيل Python script
    const pythonProcess = spawn('python', [
        path.join(__dirname, '../../ml_model/predict.py'),
        imagePath
    ]);
    
    let result = '';
    let error = '';
    
    pythonProcess.stdout.on('data', (data) => {
        result += data.toString();
    });
    
    pythonProcess.stderr.on('data', (data) => {
        error += data.toString();
    });
    
    pythonProcess.on('close', (code) => {
        if (code === 0 && result) {
            try {
                const prediction = JSON.parse(result);
                res.json({
                    success: true,
                    ...prediction,
                    pythonOutput: result
                });
            } catch (e) {
                res.status(500).json({ 
                    success: false, 
                    message: "Failed to parse Python output",
                    rawOutput: result,
                    error: error
                });
            }
        } else {
            res.status(500).json({ 
                success: false, 
                message: "Python script failed",
                errorCode: code,
                error: error
            });
        }
    });
});

// اختبار Python connection
router.get("/test", (req, res) => {
    // تشغيل Python بسيط للتأكد من الاتصال
    const pythonProcess = spawn('python', ['-c', 'import tensorflow as tf; print("{\"success\": true, \"tf_version\": \"' + tf.__version__ + '\"}")']);
    
    let output = '';
    pythonProcess.stdout.on('data', (data) => {
        output += data.toString();
    });
    
    pythonProcess.on('close', (code) => {
        if (code === 0) {
            try {
                const result = JSON.parse(output);
                res.json(result);
            } catch (e) {
                res.json({ 
                    success: false, 
                    message: "Python works but JSON parse failed",
                    raw: output 
                });
            }
        } else {
            res.status(500).json({ 
                success: false, 
                message: "Python test failed",
                code: code 
            });
        }
    });
});

// تشغيل تدريب النموذج (إذا أردت)
router.post("/train", (req, res) => {
    res.json({
        success: true,
        message: "Training started (simulated)",
        note: "في الواقع: سيشغل model_training.py",
        estimatedTime: "10-15 minutes"
    });
});

module.exports = router;