// backend/routes/analyzeRoutes.js
const express = require('express');
const router = express.Router();
const { upload, validateFile } = require('../middleware/fileValidator');
const authMiddleware = require('../auth/authMiddleware');

// ========================
// 📤 UPLOAD MRI SCAN
// ========================
router.post('/upload',
    authMiddleware.verifyToken,
    upload.single('mri_image'),
    validateFile,
    async (req, res) => {
        try {
            const { patient_id, notes } = req.body;
            const Scan = require('../models/scan');
            
            // إنشاء فحص جديد
            const scanData = {
                patient_id: patient_id || null,
                image_path: `/uploads/${req.file.filename}`,
                original_filename: req.file.originalname,
                notes: notes || ''
            };
            
            const scan = await Scan.create(scanData);
            
            res.json({
                success: true,
                message: 'MRI scan uploaded successfully',
                scan: {
                    id: scan.id,
                    image_url: `/uploads/${req.file.filename}`,
                    filename: req.file.originalname,
                    upload_date: new Date().toISOString()
                }
            });
            
        } catch (error) {
            console.error('Upload error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to upload scan',
                error: error.message 
            });
        }
    }
);

// ========================
// 🤖 ANALYZE SCAN
// ========================
router.post('/:scanId/analyze',
    authMiddleware.verifyToken,
    async (req, res) => {
        try {
            const { scanId } = req.params;
            const Scan = require('../models/scan');
            const Analysis = require('../models/analysis');
            
            // التحقق من وجود الفحص
            const scan = await Scan.findById(scanId);
            if (!scan) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Scan not found' 
                });
            }
            
            // محاكاة تحليل AI
            const hasTumor = Math.random() > 0.7;
            const confidence = (Math.random() * 0.3 + 0.7).toFixed(2);
            const tumorTypes = ['Meningioma', 'Glioma', 'Pituitary'];
            
            const analysisData = {
                scan_id: parseInt(scanId),
                has_tumor: hasTumor,
                confidence: parseFloat(confidence),
                tumor_type: hasTumor ? tumorTypes[Math.floor(Math.random() * 3)] : null,
                tumor_size: hasTumor ? (Math.random() * 3 + 1).toFixed(1) + 'cm' : null,
                notes: 'AI-generated analysis'
            };
            
            const analysis = await Analysis.create(analysisData);
            
            // تحديث حالة الفحص
            await Scan.updateStatus(scanId, 'analyzed');
            
            res.json({
                success: true,
                message: hasTumor ? '🚨 Tumor detected' : '✅ No tumor found',
                analysis: {
                    id: analysis.id,
                    has_tumor: analysis.has_tumor,
                    confidence: analysis.confidence,
                    tumor_type: analysis.tumor_type,
                    tumor_size: analysis.tumor_size,
                    analyzed_at: new Date().toISOString(),
                    recommendation: hasTumor 
                        ? 'Immediate consultation with a neurologist recommended'
                        : 'Routine follow-up in 6-12 months recommended'
                }
            });
            
        } catch (error) {
            console.error('Analysis error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to analyze scan',
                error: error.message 
            });
        }
    }
);

// ========================
// 📜 GET SCAN HISTORY
// ========================
router.get('/history',
    authMiddleware.verifyToken,
    async (req, res) => {
        try {
            const Scan = require('../models/scan');
            const scans = await Scan.getAll();
            
            res.json({
                success: true,
                count: scans.length,
                scans: scans
            });
            
        } catch (error) {
            console.error('History error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch scan history',
                error: error.message 
            });
        }
    }
);

// ========================
// 🔍 GET SINGLE SCAN
// ========================
router.get('/:scanId',
    authMiddleware.verifyToken,
    async (req, res) => {
        try {
            const { scanId } = req.params;
            const Scan = require('../models/scan');
            
            const scan = await Scan.findById(scanId);
            if (!scan) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Scan not found' 
                });
            }
            
            res.json({
                success: true,
                scan: scan
            });
            
        } catch (error) {
            console.error('Get scan error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch scan',
                error: error.message 
            });
        }
    }
);

// ========================
// 🗑️ DELETE SCAN
// ========================
router.delete('/:scanId',
    authMiddleware.verifyToken,
    async (req, res) => {
        try {
            const { scanId } = req.params;
            const Scan = require('../models/scan');
            
            const result = await Scan.delete(scanId);
            
            if (result.changes === 0) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Scan not found' 
                });
            }
            
            res.json({
                success: true,
                message: 'Scan deleted successfully',
                scanId: scanId
            });
            
        } catch (error) {
            console.error('Delete error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to delete scan',
                error: error.message 
            });
        }
    }
);

module.exports = router;