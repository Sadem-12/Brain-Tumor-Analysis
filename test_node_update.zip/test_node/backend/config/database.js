// backend/config/database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '..', 'database.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Database connection error:', err.message);
    } else {
        console.log('✅ Connected to SQLite database');
        createTables();
    }
});

function createTables() {
    // جدول المستخدمين
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT UNIQUE,
            role TEXT CHECK(role IN ('admin', 'doctor', 'patient')) DEFAULT 'patient',
            full_name TEXT,
            phone TEXT,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);
    
    // جدول المرضى
    db.run(`
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            age INTEGER,
            gender TEXT CHECK(gender IN ('male', 'female', 'other')),
            address TEXT,
            emergency_contact TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `);
    
    // جدول فحوصات MRI
    db.run(`
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER,
            image_path TEXT NOT NULL,
            original_filename TEXT,
            upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending',
            FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
        )
    `);
    
    // جدول التحليلات
    db.run(`
        CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER UNIQUE,
            has_tumor BOOLEAN DEFAULT 0,
            confidence REAL CHECK(confidence >= 0 AND confidence <= 1),
            tumor_type TEXT,
            tumor_size TEXT,
            notes TEXT,
            analyzed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            pdf_report_path TEXT,
            FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
        )
    `);
    
    // جدول التقارير
    db.run(`
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_id INTEGER,
            doctor_id INTEGER,
            diagnosis TEXT,
            recommendations TEXT,
            report_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (analysis_id) REFERENCES analyses(id) ON DELETE CASCADE,
            FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE SET NULL
        )
    `);
    
    // إضافة مستخدم admin افتراضي
    db.get("SELECT id FROM users WHERE username = 'admin'", (err, row) => {
        if (!row) {
            db.run(
                `INSERT INTO users (username, password, email, role, full_name) 
                 VALUES (?, ?, ?, ?, ?)`,
                ['admin', 'admin123', 'admin@hospital.com', 'admin', 'System Administrator']
            );
            console.log('👑 Default admin user created');
        }
    });
}

module.exports = db;