// backend/auth/authMiddleware.js
const jwt = require('jsonwebtoken');

const authMiddleware = {
    // التحقق من التوكن
    verifyToken: (req, res, next) => {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'Access token is required'
            });
        }
        
        const token = authHeader.split(' ')[1];
        
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret_key_here');
            req.userId = decoded.id;
            req.userRole = decoded.role;
            next();
        } catch (error) {
            return res.status(401).json({
                success: false,
                message: 'Invalid or expired token'
            });
        }
    },
    
    // التحقق من صلاحيات المستخدم
    checkRole: (roles) => {
        return (req, res, next) => {
            if (!roles.includes(req.userRole)) {
                return res.status(403).json({
                    success: false,
                    message: 'Insufficient permissions'
                });
            }
            next();
        };
    }
};

module.exports = authMiddleware;