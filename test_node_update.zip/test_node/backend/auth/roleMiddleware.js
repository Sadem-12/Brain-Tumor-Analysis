const roleMiddleware = (allowedRoles) => {
    return (req, res, next) => {
        try {
            // تأكد من وجود المستخدم في الطلب (يجب أن يكون authMiddleware قد أضافه)
            if (!req.user) {
                return res.status(401).json({
                    success: false,
                    message: 'غير مصرح - يرجى تسجيل الدخول أولاً'
                });
            }

            // تحقق من الصلاحيات
            if (!allowedRoles.includes(req.user.role)) {
                return res.status(403).json({
                    success: false,
                    message: 'صلاحيات غير كافية للوصول إلى هذا المسار',
                    requiredRoles: allowedRoles,
                    userRole: req.user.role
                });
            }

            // إذا كانت الصلاحيات صحيحة، اذهب للخطوة التالية
            next();
        } catch (error) {
            console.error('خطأ في التحقق من الصلاحيات:', error);
            return res.status(500).json({
                success: false,
                message: 'خطأ في التحقق من الصلاحيات'
            });
        }
    };
};

module.exports = roleMiddleware;