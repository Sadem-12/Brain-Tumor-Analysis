import sys
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from PIL import Image
import os

# تحميل النموذج المدرب
def load_tumor_model():
    try:
        model = load_model('brain_tumor_model.h5')
        print("✅ النموذج تم تحميله بنجاح")
        return model
    except Exception as e:
        print(f"❌ خطأ في تحميل النموذج: {e}")
        return None

# معالجة الصورة قبل التحليل
def preprocess_image(img_path):
    try:
        # فتح الصورة وتغيير حجمها
        img = Image.open(img_path)
        img = img.resize((150, 150))  # نفس حجم التدريب
        
        # تحويل الصورة إلى array
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array /= 255.0  # تطبيع القيم مثل التدريب
        
        print("✅ الصورة تمت معالجتها بنجاح")
        return img_array
    except Exception as e:
        print(f"❌ خطأ في معالجة الصورة: {e}")
        return None

# التنبؤ بوجود ورم
def predict_tumor(model, processed_img):
    try:
        prediction = model.predict(processed_img)
        print(f"🎯 نتيجة التنبؤ: {prediction}")
        
        # اعتماداً على عدد الفئات في تدريبك
        classes = ['glioma', 'meningioma', 'notumor', 'pituitary']  # غيريها حسب تدريبك
        
        # الحصول على أعلى احتمالية
        predicted_class = classes[np.argmax(prediction)]
        confidence = np.max(prediction)
        
        if predicted_class == 'notumor':
            return f"🟢 لا يوجد ورم - النتيجة طبيعية (ثقة: {confidence:.2f})"
        else:
            return f"🔴 يوجد ورم - نوع الورم: {predicted_class} (ثقة: {confidence:.2f}) - يرجى مراجعة الطبيب"
            
    except Exception as e:
        return f"❌ خطأ في التنبؤ: {e}"

# الدالة الرئيسية
def main():
    if len(sys.argv) < 2:
        print("❌ يرجى تقديم مسار الصورة كمعامل")
        return "error: no image path"
    
    image_path = sys.argv[1]
    
    # التحقق من وجود الصورة
    if not os.path.exists(image_path):
        print(f"❌ الصورة غير موجودة: {image_path}")
        return "error: image not found"
    
    print(f"📁 معالجة الصورة: {image_path}")
    
    # تحميل النموذج
    model = load_tumor_model()
    if model is None:
        return "error: model loading failed"
    
    # معالجة الصورة
    processed_img = preprocess_image(image_path)
    if processed_img is None:
        return "error: image processing failed"
    
    # التنبؤ
    result = predict_tumor(model, processed_img)
    print(f"📊 النتيجة النهائية: {result}")
    
    return result

if name == "__main__":
    result = main()
    print(result)  # هذا ما يرجعه لـ Node.js