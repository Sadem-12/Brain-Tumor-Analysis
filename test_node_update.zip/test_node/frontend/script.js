document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('uploadForm');
  const fileInput = document.getElementById('imageInput');
  const resultEl = document.getElementById('result');
  const preview = document.getElementById('preview');
  const submitBtn = document.getElementById('analyzeBtn');

  // معاينة الصورة بعد الاختيار
  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (!file) {
      preview.src = '';
      return;
    }
    if (!file.type.startsWith('image/')) {
      alert('حطي صورة بصيغة PNG أو JPG');
      fileInput.value = '';
      preview.src = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => preview.src = e.target.result;
    reader.readAsDataURL(file);
  });

  // عند ارسال الفورم نرفع الصورة عن طريق fetch (FormData)
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    resultEl.textContent = '';

    const file = fileInput.files[0];
    if (!file) {
      alert('اختاري صورة أول');
      return;
    }

    // حد حجم اختياري (مثال 10 ميغا)
    const MAX_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      alert('الصورة كبيرة جدًا (أقصى 10 ميغابايت)');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'جاري الرفع...';

    try {
      const formData = new FormData();
      formData.append('image', file); // مهم: الاسم "image" لازم يتطابق مع multer

      const res = await fetch('/api/analyze', {
        method: 'POST',
        body: formData
        // لا تضيفي headers هنا — المتصفح يضبط Content-Type تلقائياً
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`خطأ من السيرفر: ${res.status} ${text}`);
      }

      const data = await res.json();
      // عرض جميل للـ JSON
      resultEl.textContent = JSON.stringify(data, null, 2);
    } catch (err) {
      resultEl.textContent = 'خطأ: ' + err.message;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'حلل الصورة';
    }
  });
});