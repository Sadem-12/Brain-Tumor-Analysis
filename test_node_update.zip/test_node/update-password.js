const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

const dbPath = path.join(__dirname, 'backend', 'database.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Database connection error:', err.message);
        process.exit(1);
    } else {
        console.log('✅ Connected to SQLite database');
        updatePassword();
    }
});

async function updatePassword() {
    try {
        const hashedPassword = await new Promise((resolve, reject) => {
            bcrypt.hash('admin123', 10, (err, hash) => {
                if (err) reject(err);
                else resolve(hash);
            });
        });

        db.run(
            "UPDATE users SET password = ? WHERE username = 'admin'",
            [hashedPassword],
            function(err) {
                if (err) {
                    console.error('❌ Error updating password:', err.message);
                } else {
                    console.log('✅ Password updated successfully');
                    console.log('👤 Username: admin');
                    console.log('🔐 Password: admin123');
                }
                db.close();
                process.exit(0);
            }
        );
    } catch (error) {
        console.error('❌ Error:', error.message);
        db.close();
        process.exit(1);
    }
}
